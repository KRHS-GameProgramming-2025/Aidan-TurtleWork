from shapes_new import *

def house (t, size = 10, color=None):
  square(t, size*3, 0, None, color)
  move(t, size*-1, size*3)
  equilateral_tri(t, size*5, 0, None, "black")
  move(t, size*1, size*-3)

  move(t, size*.5, 0)
  door(t, size, "red")
  move(t, size*-.5,0)

def door(t, size =10, color=None):
  rect(t, size*.5, size*1, 0, None, color)
