import turtle
from drawing import *
bob=Turtle()
bob.speed(0)

house(bob, 15, "blue")



done()
